package com.pamesa.intents;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private EditText etName;
    private EditText etBirthday;
    private EditText etPhone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etBirthday = findViewById(R.id.etBirthday);
        etPhone = findViewById(R.id.etPhone);

        Button btnProceed = findViewById(R.id.btnProceed);
        btnProceed.setOnClickListener(v -> proceed());
    }

    private void proceed() {
        String name = etName.getText().toString().trim();
        String birthday = etBirthday.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();

        if (name.isEmpty()) {
            etName.setError("Name is required");
            return;
        }
        if (birthday.isEmpty()) {
            etBirthday.setError("Birthday is required");
            return;
        }
        if (!isValidBirthday(birthday)) {
            etBirthday.setError("Use MM/DD/YYYY, for example 01/31/2000");
            return;
        }
        if (phone.isEmpty()) {
            etPhone.setError("Phone number is required");
            return;
        }
        if (!phone.matches("09\\d{9}")) {
            etPhone.setError("Use 11 digits starting with 09");
            return;
        }

        Intent intent = new Intent(this, ResultActivity.class);
        intent.putExtra(ResultActivity.EXTRA_NAME, name);
        intent.putExtra(ResultActivity.EXTRA_BIRTHDAY, birthday);
        intent.putExtra(ResultActivity.EXTRA_PHONE, phone);
        startActivity(intent);
    }

    // The regex keeps the two-digit month and day; the non-lenient parser rejects dates like 02/30/2000
    private boolean isValidBirthday(String text) {
        if (!text.matches("\\d{2}/\\d{2}/\\d{4}")) {
            return false;
        }
        SimpleDateFormat format = new SimpleDateFormat("MM/dd/yyyy", Locale.US);
        format.setLenient(false);
        try {
            Date date = format.parse(text);
            return date != null && !date.after(new Date());
        } catch (ParseException e) {
            return false;
        }
    }
}
