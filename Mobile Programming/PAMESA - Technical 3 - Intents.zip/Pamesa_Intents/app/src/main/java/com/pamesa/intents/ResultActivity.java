package com.pamesa.intents;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    public static final String EXTRA_NAME = "name";
    public static final String EXTRA_BIRTHDAY = "birthday";
    public static final String EXTRA_PHONE = "phone";

    // Zodiac sign of month m is SIGNS[m - 1] up to LAST_DAY[m - 1], then SIGNS[m] after it
    private static final String[] SIGNS = {"Capricorn", "Aquarius", "Pisces", "Aries", "Taurus", "Gemini",
            "Cancer", "Leo", "Virgo", "Libra", "Scorpio", "Sagittarius", "Capricorn"};
    private static final int[] LAST_DAY = {19, 18, 20, 19, 20, 20, 22, 22, 22, 22, 21, 21};

    // Each row is {network, prefixes}. The five-digit Globe Postpaid prefixes come first so they win over their four-digit starts.
    private static final String[][] CARRIERS = {
            {"Globe Postpaid", "09175,09176,09178,09253,09255,09256,09257,09258"},
            {"Globe Telecom / Gomo / TM", "0976"},
            {"ABS-CBN Mobile", "0937"},
            {"Cherry Prepaid", "0996"},
            {"Globe Telecom / Touch Mobile / TM",
                    "0817,0905,0906,0915,0916,0917,0926,0927,0935,0936,0945,0955,0956,0965,0966,0967,0975,0977,0995,0997"},
            {"Smart / Talk N Text / TNT",
                    "0813,0907,0908,0909,0910,0811,0912,0913,0914,0918,0919,0920,0921,0928,0929,0930,0938,0939,0940,"
                            + "0946,0947,0948,0949,0950,0951,0961,0963,0968,0969,0970,0981,0989,0992,0998,0999"},
            {"Dito", "0895,0896,0897,0898,0991,0992,0993,0994"},
            {"Sun Cellular", "0922,0923,0924,0925,0931,0932,0933,0934,0941,0942,0943,0944"},
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        String name = getIntent().getStringExtra(EXTRA_NAME);
        String birthday = getIntent().getStringExtra(EXTRA_BIRTHDAY);
        String phone = getIntent().getStringExtra(EXTRA_PHONE);

        ((TextView) findViewById(R.id.tvName)).setText(name);
        ((TextView) findViewById(R.id.tvBirthday)).setText(birthday + "  -  " + getZodiac(birthday));
        ((TextView) findViewById(R.id.tvPhone)).setText(phone + "  -  " + getCarrier(phone));

        Button btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish());
    }

    private String getZodiac(String birthday) {
        int month = Integer.parseInt(birthday.substring(0, 2));
        int day = Integer.parseInt(birthday.substring(3, 5));
        if (day <= LAST_DAY[month - 1]) {
            return SIGNS[month - 1];
        }
        return SIGNS[month];
    }

    private String getCarrier(String phone) {
        for (String[] carrier : CARRIERS) {
            for (String prefix : carrier[1].split(",")) {
                if (phone.startsWith(prefix)) {
                    return carrier[0];
                }
            }
        }
        return "Unknown/Unlisted Carrier";
    }
}
