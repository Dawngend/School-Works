package com.pamesa.activitylifecycle;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "PamesaLifecycle";
    private static final String NAME = "Dawn Andrei Pamesa";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d(TAG, NAME + " is calling onCreate()");

        // onDestroy() is not guaranteed when the system kills the process, so finish() triggers it on purpose
        Button btnFinish = findViewById(R.id.btnFinish);
        btnFinish.setOnClickListener(v -> finish());
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(TAG, NAME + " is calling onStart()");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, NAME + " is calling onResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d(TAG, NAME + " is calling onPause()");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d(TAG, NAME + " is calling onStop()");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(TAG, NAME + " is calling onRestart()");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d(TAG, NAME + " is calling onDestroy()");
    }
}
