package com.pamesa.studentprofile;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        // Let the green header run under the status bar, and push the title below it instead
        TextView tvProfileTitle = findViewById(R.id.tvProfileTitle);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, 0, systemBars.right, systemBars.bottom);
            tvProfileTitle.setPadding(0, systemBars.top, 0, 0);
            return insets;
        });
        // White status bar icons on the green header
        new WindowInsetsControllerCompat(getWindow(), getWindow().getDecorView())
                .setAppearanceLightStatusBars(false);

        // Student Number is assigned programmatically, not from the layout or strings.xml
        String studentNumber = "202411754";
        TextView tvStudentNumber = findViewById(R.id.tvStudentNumber);
        tvStudentNumber.setText(studentNumber);
    }
}
